﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryTracker.Models
{
    public class MockProductRepository : IProductRepository
    {
        private readonly List<Product> _productList;

        public MockProductRepository()
        {
            _productList = new List<Product>()
            {
                new Product(){ProductId = 1, ProductName = "Lipstick", ProductCategory = ProductCategory.Cosmetics,Status = DeliveryStatus.Delivered},
                new Product(){ProductId = 2, ProductName = "Dates", ProductCategory = ProductCategory.DryFruit,Status = DeliveryStatus.Pending},
                new Product(){ProductId = 3, ProductName = "Banana", ProductCategory = ProductCategory.Vegetables,Status = DeliveryStatus.Pending},

            };
        }

        public Product Add(Product product)
        {
            throw new NotImplementedException();
        }

        public Product Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Product> GetAllProduct()
        {
            return _productList;
        }

        public Product GetProduct(int Id)
        {
            return _productList.FirstOrDefault(p => p.ProductId == Id);
        }

        public Product Update(Product product)
        {
            throw new NotImplementedException();
        }
    }
}
