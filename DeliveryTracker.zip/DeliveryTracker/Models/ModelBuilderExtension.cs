﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryTracker.Models
{
    public static class ModelBuilderExtension
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductId = 1,
                    ProductName = "Banana",
                    ProductCategory = ProductCategory.Vegetables,
                    Status = DeliveryStatus.Delivered
                },
                new Product
                {
                    ProductId = 2,
                    ProductName = "Dates",
                    ProductCategory = ProductCategory.DryFruit,
                    Status = DeliveryStatus.Pending
                },
                new Product
                {
                    ProductId = 3,
                    ProductName = "Lipstick",
                    ProductCategory = ProductCategory.Cosmetics,
                    Status = DeliveryStatus.CannotDelivered
                }
                ); 
        }
    }
}
