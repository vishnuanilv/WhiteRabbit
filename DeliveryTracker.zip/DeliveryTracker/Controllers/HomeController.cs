﻿using DeliveryTracker.Models;
using DeliveryTracker.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryTracker.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductRepository _productRepository;

        public HomeController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        public ViewResult Index()
        {
            var model = _productRepository.GetAllProduct();
            return View(model);
        }

        public ViewResult Details(int Id)
        {
            Product product = _productRepository.GetProduct(Id);

            if (product == null)
            {
                Response.StatusCode = 404;
                return View("EmployeeNotFound", Id);
            }

            HomeDetailsViewModel homeDetailsViewModel = new HomeDetailsViewModel()
            {
                Product = product,
                PageTitle = "Product Details"
            };

            return View(homeDetailsViewModel);
        }

        [HttpPost]
        public IActionResult Create(ProductCreateViewModel model)
        {
            if (ModelState.IsValid)
            {
                Product newProduct = new Product
                {
                    ProductName = model.ProductName,
                    ProductCategory = model.Category,
                    Status = model.Status
                };

                _productRepository.Add(newProduct);
                return RedirectToAction("details", new { id = newProduct.ProductId });
            }

            return View();
        }

        
        [HttpPost]
        public IActionResult Edit(ProductEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                Product product = _productRepository.GetProduct(model.ProductId);
                product.ProductName = model.ProductName;
                product.ProductCategory = model.Category;
                product.Status = model.Status;
                
                Product updatedProduct = _productRepository.Update(product);

                return RedirectToAction("index");
            }

            return View(model);
        }
    }
}
